## IPL social (examen)

### Nom : GIJSEN
### Prénom : William 

### Description
#### Projet Git Action qui permet l'utilisation d'une pipeline CI pour les Merge/Pull requests. A chaque MR/PR effectué, le pipeline se lance et effectue automatiquement un scénario de tests définis par l'utilisateur.

### Lancer manuellement les tests :
```
npm run test
```

